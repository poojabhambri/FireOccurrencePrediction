/* this is set up for alberta now



jan 05
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>


typedef double alldata[600][3];
  float codes[18010][10];
  float ERlocation[18010][2];
  int ecoregion[18010],year[18010];

void distance(double *x, double *y, float cent_lat, float cent_long, 
              float lat, float lon);
float calculate(alldata cf, int NUM, float lat,float lon, float min,float max);

int main() {

  FILE  *inp[10], *out,*points;

  alldata interp;
  int yr,mon,day,i,j,k,err, NUM,REGIONS;  
  float lat, lon;
  float max, min, latmax,latmin,longmin,longmax;

   inp[0] = fopen("CF-temp.ab7512", "r");
   inp[1] = fopen("CF-rh.ab7512", "r");
   inp[2] = fopen("CF-ws.ab7512", "r");
   inp[3] = fopen("CF-rain.ab7512", "r");
   inp[4] = fopen("CF-ffmc.ab7512", "r");
   inp[5] = fopen("CF-dmc.ab7512", "r");
   inp[6] = fopen("CF-dc.ab7512", "r");
   inp[7] = fopen("CF-isi.ab7512", "r");
   inp[8] = fopen("CF-bui.ab7512", "r");
   inp[9] = fopen("CF-fwi.ab7512", "r");

   points=fopen("firesLOCS.txt","r");
   out=fopen(   "firewxAB1983_2011.out","w");  
   if(points==NULL)printf("Points file no found\n");
   if(inp[1]==NULL)printf("INPUT 1   file no found\n");

   err=fscanf(points,"%d%d%f%f",&ecoregion[0],&year[0],&ERlocation[0][0],&ERlocation[0][1]);

   REGIONS=0;
   while(err>=0){
       printf("%5d == lat= %7.2f  lon= %7.2f\n",
           REGIONS,ERlocation[REGIONS][0],ERlocation[REGIONS][1]);
       REGIONS++;

       err=fscanf(points,"%d%d%f%f",&ecoregion[REGIONS],&year[REGIONS],
              &ERlocation[REGIONS][0],&ERlocation[REGIONS][1]);
   }
   fclose(points);

   printf("done --%d grids\n",REGIONS);

   err=1; 
   while(err>=0){   /* go thru one day at a time */
      for(i=0;i<10;i++)for(j=0;j<18010;j++)codes[j][i]=-999.9;
      for(i=0;i<10;i++){   /* go thru each index */
        err=fscanf(inp[i],"%4d%2d%2d%3d%6f%6f%7f%7f%7f%7f",
              &yr,&mon,&day,&NUM,&min,&max,&latmin,&latmax,&longmin,&longmax);
        for(k=0;k<600;k++)err=fscanf(inp[i],"%8lf%8lf%14lf",
                &interp[k][0],&interp[k][1],&interp[k][2]);
       /* now go thru all points and fill in matrix*/
        if(yr>1982)for(j=0;j<REGIONS;j++){  /* ************* YEAR exclusion */
          lat=ERlocation[j][0];
          lon=ERlocation[j][1];
          if(NUM>0 && yr==year[j])
               codes[j][i]=calculate(interp,NUM,lat,lon,min,max);
        }  /* then the loop thur the ER locations  */
      } /* end the i=1->10 loop */
      printf("%d  %d %d\n",yr,mon,day);
      for(j=0;j<REGIONS;j++){
          if(codes[j][1]>-900.0 && yr==year[j]){   /* its not a missing value ****  YEAR exclusion*/   
             fprintf(out,"%6d %4d %2d %2d ",ecoregion[j],yr,mon,day);
             for(i=0;i<10;i++)fprintf(out,"%5.1f ",codes[j][i]);
             fprintf(out,"%6.2f\n",0.0272*pow(codes[j][9],1.77) );  /*DSR*/
          }
      } /* printed out all regions now */

      if(mon==10 && day==31 && yr==2012) err=-1;

   } /* end the while....get the next day*/
   for(i=0;i<10;i++)fclose(inp[i]);
   fclose(out);
     return(1);
}

/* functions julian & nailuj taken from /disk15/mwotton/progs/nailuj.c  */



float calculate(alldata cf, int NUM, float lat,float lon, float min,float max)
{
  int i;
  double ds,x,y;
  double calc;
  
  calc=cf[NUM][2]+ lon*cf[NUM+1][2]+lat*cf[NUM+2][2];
  for(i=0;i<NUM;i++){
    ds=sqrt( (lat-cf[i][0])*(lat-cf[i][0])+(lon-cf[i][1])*(lon-cf[i][1]) );
    if (ds>0.00001 )calc+=cf[i][2]*ds*ds*log(ds);
  } 
 
 if(calc>max) calc=max;
 if(calc<min) calc=min;
 return (float)(calc);
}    

